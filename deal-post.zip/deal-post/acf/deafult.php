<?php
/* deafult fields added to post type deal
Author: Rohit Kaushik
*/
    acf_add_local_field_group(array(
        'key' => 'group_1',
        'title' => 'Deals Details',
        'fields' => array (
            array (
                'key' => 'field_1',
                'label' => 'Launch Year',
                'name' => 'launch_year',
                'type' => 'date_picker',
                'wrapper' => array (
                        'width' => '50%',
                    ),
                ),
            array (
                    'key' => 'field_2',
                    'label' => 'Founders',
                    'name' => 'founders',
                    'type' => 'text',
                    'wrapper' => array (
                            'width' => '50%',
                        ),
                    ),
            array (
                        'key' => 'field_3',
                        'label' => 'Funding Amount',
                        'name' => 'funding_amount',
                        'type' => 'number',
                        'wrapper' => array (
                                'width' => '50%',
                            ),
                    ),
            array (
                        'key' => 'field_4',
                        'label' => 'Investors',
                        'name' => 'investors',
                        'type' => 'text',
                        'wrapper' => array (
                                'width' => '50%',
                            ),
                    ),
            array (
                        'key' => 'field_5',
                        'label' => 'Article Title',
                        'name' => 'article_title',
                        'type' => 'text',
                        'wrapper' => array (
                                'width' => '50%',
                            ),
                    ),
            array (
                        'key' => 'field_6',
                        'label' => 'Link to Article',
                        'name' => 'link_to_article',
                        'type' => 'url',
                        'wrapper' => array (
                                'width' => '50%',
                            ),
                    ),

        ),
        
        'location' => array (
            array (
                array (
                    'param' => 'post_type',
                    'operator' => '==',
                    'value' => 'deals',
                    
                ),
            ),
        ),
    ));
    ?>