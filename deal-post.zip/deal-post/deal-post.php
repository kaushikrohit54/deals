<?php
/**
 * Plugin Name: Deals Post
 * Description: This plugin require ACF plugin to add deafult fields, Please install and activate ACF plugin before to activate this plugin.
 * Version: 1.0
 * Author: Rohit Kaushik
 * Author URI: https://in.linkedin.com/in/rohit-kaushik-108a2383
 */
 ?>
 <?php
 
/*
* Creating a function to create our CPT
*/
function my_scripts() {
    wp_enqueue_style('bootstrap4', 'https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css');
    wp_enqueue_style('custom_css', plugins_url( '/assets/css/custom.css' , __FILE__ ));
    wp_enqueue_script('custom_js', plugins_url( '/assets/js/custom.js' , __FILE__ ));
    wp_enqueue_script('read_more', plugins_url( '/assets/js/readMoreJS.min.js' , __FILE__ ));
    wp_enqueue_script( 'boot1','https://code.jquery.com/jquery-3.3.1.slim.min.js', array( 'jquery' ),'',true );
    wp_enqueue_script( 'boot2','https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js', array( 'jquery' ),'',true );
    wp_enqueue_script( 'boot3','https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js', array( 'jquery' ),'',true );
}
add_action( 'wp_enqueue_scripts', 'my_scripts' );

function custom_post_type() {
 
// Set UI labels for Custom Post Type
    $labels = array(
        'name'                => _x( 'Deals', 'Post Type General Name', 'twentythirteen' ),
        'singular_name'       => _x( 'Deal', 'Post Type Singular Name', 'twentythirteen' ),
        'menu_name'           => __( 'Deals', 'twentythirteen' ),
        'parent_item_colon'   => __( 'Parent deal', 'twentythirteen' ),
        'all_items'           => __( 'All Deals', 'twentythirteen' ),
        'view_item'           => __( 'View Deal', 'twentythirteen' ),
        'add_new_item'        => __( 'Add New Company', 'twentythirteen' ),
        'add_new'             => __( 'Add New', 'twentythirteen' ),
        'edit_item'           => __( 'Edit Company', 'twentythirteen' ),
        'update_item'         => __( 'Update Company', 'twentythirteen' ),
        'search_items'        => __( 'Search Company', 'twentythirteen' ),
        'not_found'           => __( 'Not Found', 'twentythirteen' ),
        'not_found_in_trash'  => __( 'Not found in Trash', 'twentythirteen' ),
			'featured_image'        => __( 'Company Logo', 'twentythirteen' ),
		// Overrides the “Set featured image” label
		'set_featured_image'    => __( 'Set company logo', 'twentythirteen' ),
		// Overrides the “Remove featured image” label
		'remove_featured_image' => _x( 'Remove company logo', 'twentythirteen' ),

    );

     
// Set other options for Custom Post Type
     
    $args = array(
        'label'               => __( 'deals', 'twentythirteen' ),
        'description'         => __( 'deals news and reviews', 'twentythirteen' ),
        'labels'              => $labels,
        // Features this CPT supports in Post Editor
        'supports'            => array( 'title', 'thumbnail', 'revisions', 'custom-fields', ),
        // You can associate this CPT with a taxonomy or custom taxonomy. 
         /* A hierarchical CPT is like Pages and can have
        * Parent and child items. A non-hierarchical CPT
        * is like Posts.
        */ 
        'hierarchical'        => false,
        'public'              => true,
        'show_ui'             => true,
        'show_in_menu'        => true,
        'show_in_nav_menus'   => true,
        'show_in_admin_bar'   => true,
        'menu_position'       => 5,
        'can_export'          => true,
        'has_archive'         => true,
        'exclude_from_search' => false,
        'publicly_queryable'  => true,
        'capability_type'     => 'page',
		
    );
     
    // Registering your Custom Post Type
    register_post_type( 'deals', $args );
 
}
function wpb_change_title_text( $title ){
    $screen = get_current_screen();
 
    if  ( 'deals' == $screen->post_type ) {
         $title = 'Name of the Company';
    }
 
    return $title;
}
 
add_filter( 'enter_title_here', 'wpb_change_title_text' );
 add_action( 'init', 'custom_post_type', 0 );

function sector_taxonomy() {  
    register_taxonomy(  
        'sector',  //The name of the taxonomy. Name should be in slug form (must not contain capital letters or spaces). 
        'deals',        //post type name
        array(  
            'hierarchical' => true,  
            'label' => 'Sectors',  //Display name
            'query_var' => true,
            'rewrite' => array(
                'slug' => 'sector', // This controls the base slug that will display before each term
                'with_front' => false // Don't display the category base before 
            )
        )  
    );  
}  
add_action( 'init', 'sector_taxonomy');
function deal_stage_taxonomy() {  
    register_taxonomy(  
        'deal_stage',  //The name of the taxonomy. Name should be in slug form (must not contain capital letters or spaces). 
        'deals',        //post type name
        array(  
            'hierarchical' => true,  
            'label' => 'Deal Stage',  //Display name
            'query_var' => true,
            'rewrite' => array(
                'slug' => 'deal_stage', // This controls the base slug that will display before each term
                'with_front' => false // Don't display the category base before 
            )
        )  
    );  
}  
add_action( 'init', 'deal_stage_taxonomy');




//shortcodes 

function dealss( $atts ) {
global $post,$wpdb;
            ob_start();
           $args = array( 
           'post_type' => 'deals',
           'order' => 'asc'
        );
        $deal_query = new WP_Query( $args );

while ($deal_query->have_posts()) : $deal_query->the_post();
$terms = get_the_terms( $post->ID, 'sector' );
include 'templates/shortcode.php';
endwhile;
wp_reset_query();
return ob_get_clean();

}
add_shortcode( 'all-deals', 'dealss' );



function load_deal_template( $template ) {
    global $post;

    if ( 'deals' === $post->post_type && locate_template( array( 'single-deal.php' ) ) !== $template ) {
        
        include 'templates/single-deal.php';
        
    }

    return $template;
    
}

add_filter( 'single_template', 'load_deal_template', 99 );

add_filter( 'archive_template', 'myplugin_archive_template' );
function myplugin_archive_template( $templates ) {
    global $post;
    if ( 'deals' == $post->post_type ) {
             include 'templates/archive-deals.php';
        
    }
    
    return $templates;
   
}









//ACF deafult fields added here 
if( function_exists('acf_add_local_field_group') ):
    include 'acf/deafult.php';
    
    endif;


//single shortcode

add_shortcode('deal-card', 'single_deal');
function single_deal($atts, $content){
    extract(shortcode_atts(array( // a few default values
    'id' => null,
    'posts_per_page' => '1',
    'caller_get_posts' => 1)
    , $atts));
    $args = array(
    'post_type' => 'deals',
    'numberposts' => -1
    );

    if($atts['id']){
     $args['p'] = $atts['id'];
    }

    global $post;
    $posts = new WP_Query($args);
    $output = '';


    if ($posts->have_posts())
        while ($posts->have_posts()):
            $posts->the_post();
            
?>

            <div class="col-md-3 col-sm-12 float-left one_deal">
<div class="deal_content">
	<div class="posters">
    <div class="deal_into">
	<div class="col-md-4 col-sm-12 float-left thumnail">
		<?php twentysixteen_post_thumbnail(); ?>
	</div>
		<div class="col-md-8 col-sm-12 float-left title">
        <p class="deal_title"><?php the_title( sprintf( '<a href="%s" rel="bookmark">', esc_url( get_permalink() ) ), '</a>' ); ?></p>
			<p class="sector_name"><strong>Sector:</strong>
             <?php 
             $terms = get_the_terms($post->ID, 'sector' );
             
             if ($terms) {
		   foreach($terms as $term) {
			    print_r($term->name);
			     } } ?></p>
		</div>
        </div>
	<div class="description clearfix metass">
		<p class="launch_yr"><strong>Launch:</strong> <?php echo get_field( "launch_year" );?>	
			<p class="founder launch_yr"><strong>Founders:</strong> <?php echo get_field( "founders" );?>
			<p class="investes launch_yr"><strong>Investors:</strong> <?php echo get_field( "investors" );?></p>
		<p class="launch_yr"><b>News: </b><a href="<?php echo get_field( 'link_to_article' );?>"><?php echo get_field( "article_title" );?></a></p>

	</div>
    </div>
</div>
</div>
<?php
        endwhile;
    else
    return; // no posts found
    wp_reset_query();
    return html_entity_decode($out);
}