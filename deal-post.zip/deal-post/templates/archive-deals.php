<?php
/**
 * The template for displaying archive deals
  *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package WordPress
 * @subpackage Deals
 * @since deals
 */

get_header(); ?>


<main id="main" class="site-main" role="main">
	<div class="row">
		<?php
	$loop = new WP_Query( array( 'post_type' => 'deals' ) );
    if ( $loop->have_posts() ) :
        while ( $loop->have_posts() ) : $loop->the_post(); ?>



		<div class="col-md-3 col-sm-6 float-left">
			<div class="deal_content">
				<div class="deal_into">
					<?php if ( has_post_thumbnail() ) { ?>
					<div class="col-md-4 float-left">
						<a href="<?php the_permalink(); ?>"><?php the_post_thumbnail(); ?></a>
					</div>
					<?php } ?>
					<div class="col-md-8 float-left">
						<p class="deal_title">
							<?php the_title( sprintf( '<a href="%s" rel="bookmark">', esc_url( get_permalink() ) ), '</a>' ); ?>
						</p>
						<p class="sector"><b>Sector:</b>
							<?php
				$terms = get_the_terms( $post->ID, 'sector' );
				if ($terms) {
					$num_of_items = count($terms);
					$num_count = 0;
					foreach($terms as $term) {
					  echo $term->name;
					  $num_count = $num_count + 1;
					  if ($num_count < $num_of_items) {
						echo ", ";
					  }
					} 
					
				}?></p>
					</div>
				</div>
				<div class="description">
					<p class="launch_yr"><b>Launch: </b><?php echo get_field( "launch_year" );?></p>
					<p class="launch_yr"><b>Founders: </b><span
							class="investor"><?php echo get_field( "founders" );?></span></p>
					<div class="investes launch_yr flaot-left"><strong>Investors:</strong> <span
							class="investor"><?php echo get_field( "investors" );?></span></div>
					<p class="launch_yr"><b>News: </b><a
							href="<?php  the_permalink(); ?>"><?php echo get_field( "article_title" );?></a>
					</p>

				</div>
			</div>
		</div>




		<?php
		
	
	endwhile;
		endif;
		
   ?>

	</div>
	<script>
		$readMoreJS.init({
			target: '.investor',
			numOfWords: 2,
			toggle: true,
			moreLink: '++',
			lessLink: ''
		});
	</script>
</main><!-- .site-main -->




<?php get_footer(); 