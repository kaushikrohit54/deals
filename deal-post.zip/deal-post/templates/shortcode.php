<div class="col-md-3 col-sm-12 float-left one_deal">
<div class="deal_content">
	<div class="posters">
    <div class="deal_into">
	<div class="col-md-4 col-sm-12 float-left thumnail">
		<?php twentysixteen_post_thumbnail(); ?>
	</div>
		<div class="col-md-8 col-sm-12 float-left title">
        <p class="deal_title"><?php the_title( sprintf( '<a href="%s" rel="bookmark">', esc_url( get_permalink() ) ), '</a>' ); ?></p>
			<p class="sector_name"><strong>Sector:</strong>
             <?php if ($terms) {
		   foreach($terms as $term) {
			    print_r($term->name);
			     } } ?></p>
		</div>
        </div>
	<div class="description clearfix metass">
		<p class="launch_yr"><strong>Launch:</strong> <?php echo get_field( "launch_year" );?>	
			<p class="founder launch_yr"><strong>Founders:</strong> <?php echo get_field( "founders" );?>
			<p class="investes launch_yr"><strong>Investors:</strong> <?php echo get_field( "investors" );?></p>
		<p class="launch_yr"><b>News: </b><a href="<?php echo get_field( 'link_to_article' );?>"><?php echo get_field( "article_title" );?></a></p>

	</div>
    </div>
</div>
</div>