<?php

get_header(); ?>

<div id="main-content" class="main-content">

    <div id="primary" class="content-area">
        <div id="content" class="site-content" role="main">
  
    <div class="col-md-12 float-left">
    <div class="col-md-6 float-left">
    <?php if(has_post_thumbnail() ) { the_post_thumbnail(); } ?>
    </div>
    <div class="col-md-6 float-left">
    <h2><?php the_title();?></h2>
    <p class="sector"><b>Sector:</b>
				<?php
				$terms = get_the_terms( $post->ID, 'sector' );
				if ($terms) {
					$num_of_items = count($terms);
					$num_count = 0;
					foreach($terms as $term) {
					  echo $term->name;
					  $num_count = $num_count + 1;
					  if ($num_count < $num_of_items) {
						echo ", ";
					  }
					} 
					
				}?></p>
    <div class="description clearfix metass">
    <p class="sector"><b>Deal Stage:</b>
				<?php
				$terms = get_the_terms( $post->ID, 'deal_stage' );
				if ($terms) {
					$num_of_items = count($terms);
					$num_count = 0;
					foreach($terms as $term) {
					  echo $term->name;
					  $num_count = $num_count + 1;
					  if ($num_count < $num_of_items) {
						echo ", ";
					  }
					} 
					
				}?></p>
		<p class="launch_yr"><strong>Launch:</strong> <?php echo get_field( "launch_year" );?>	
			<p class="founder launch_yr"><strong>Founders:</strong> <?php echo get_field( "founders" );?>
			<div class="investes launch_yr flaot-left"><strong>Investors:</strong> <span class="investor"><?php echo get_field( "investors" );?></span></div>
		<p class="launch_yr"><b>News: </b><a data-toggle="modal" data-target="#myModal"><?php echo get_field( "article_title" );?></a></p>

	</div>
    </div>
    </div>
<script>
    $readMoreJS.init({
    target: '.investor',
    numOfWords: 2,
    toggle: true,
    moreLink: '++',
    lessLink: ''
});
</script>
<div class="modal fade" id="myModal" role="dialog">
<div class="deal_contnen modal-dialog ">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
<div class="modal-content">
    <div class="col-md-6 float-left">
    <?php if(has_post_thumbnail() ) { the_post_thumbnail(); } ?>
    </div>
    <div class="col-md-6 float-left">
    <h2><?php the_title();?></h2>
    <p class="sector"><b>Sector:</b>
				<?php
				$terms = get_the_terms( $post->ID, 'sector' );
				if ($terms) {
					$num_of_items = count($terms);
					$num_count = 0;
					foreach($terms as $term) {
					  echo $term->name;
					  $num_count = $num_count + 1;
					  if ($num_count < $num_of_items) {
						echo ", ";
					  }
					} 
					
				}?></p>
    <div class="description clearfix metass">
    <p class="sector"><b>Deal Stage:</b>
				<?php
				$terms = get_the_terms( $post->ID, 'deal_stage' );
				if ($terms) {
					$num_of_items = count($terms);
					$num_count = 0;
					foreach($terms as $term) {
					  echo $term->name;
					  $num_count = $num_count + 1;
					  if ($num_count < $num_of_items) {
						echo ", ";
					  }
					} 
					
				}?></p>
		<p class="launch_yr"><strong>Launch:</strong> <?php echo get_field( "launch_year" );?>	
			<p class="founder launch_yr"><strong>Founders:</strong> <?php echo get_field( "founders" );?>
			<div class="investes launch_yr flaot-left"><strong>Investors:</strong> <span class="investor"><?php echo get_field( "investors" );?></span></div>
		<p class="launch_yr"><b>News: </b><a href="<?php echo get_field( 'link_to_article' );?>"><?php echo get_field( "article_title" );?></a></p>
</div>
	</div>
    </div>
    </div>

</div>

    
   
        </div><!-- #content -->
    </div><!-- #primary -->
</div><!-- #main-content -->

<?php get_footer();